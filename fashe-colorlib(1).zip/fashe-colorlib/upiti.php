<?php

$korisnikPostoji="SELECT email FROM korisnici WHERE email=:email";
$upisKorisnikaUpit="INSERT INTO korisnici
VALUES('',:ime,:prezime,:email,:password,:idGrad,:idUloge)";


$upitLog="SELECT * FROM korisnici WHERE email=:email AND password=:pas";




?>