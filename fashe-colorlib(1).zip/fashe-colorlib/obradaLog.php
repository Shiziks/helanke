<?php

//echo"alert('radi');";
session_start();
include("konekcija.php");
include("upiti.php");
if(isset($_POST['login'])){
    
    /////////////////////////////////REGULARNI IZRAZI/////////////////////////////////
    $regEmail="/^[a-zA-Z0-9\.\_]{4,}\@[a-z0-9]{3,}.([a-z]{2,3}){1,2}$/";
    $regPas="/^([a-zA-Z0-9@*#\.\_]{8,})$/";
    

    /////////////////////////////HVATANJE PODATAKA///////////////////////////////////
    $greske=[];
    $email=$_POST['emailLog'];
    $pas=$_POST['passLog'];
    //var_dump($mejl);
    //var_dump($pas);

    ///////////////////////////PROVERA PODATAKA/////////////////////////////////////
        if(isset($email) and !empty($email)){
                
            if(!preg_match($regEmail, $email)){
                $greske[]="Email nije u dobrom formatu.";
            }
        }
        else $greske[]="Email adresa nije uneta.";

        if(isset($pas) and !empty($pas)){
            
            if(!preg_match($regPas, $pas)){
                $greske[]="Lozinka nije u dobrom formatu.";
            }
        }
        else $greske[]="Lozinka nije uneta.";

        //var_dump($greske);

        if(count($greske)>0){
           $_SESSION['greske']=$greske;
           //var_dump($greske);
            header('Location:logovanje.php');
        }
        else{
           
            if($konekcija){
                var_dump($konekcija);
                $pas=md5($pas);
                var_dump($pas);
                $upit=$konekcija->prepare($upitLog);
                $upit->bindParam(':email',$email);
                $upit->bindParam(':pas',$pas);

                try{
                    $upit->execute();
                    $rez=$upit->fetchAll();
                    var_dump($rez);
                    if(count($rez)>0){
                        $_SESSION['korisnik']=$rez;
                        header('Location:korisnik.php');
                        
                        
                    }
                    else{
                        $greske[]="Pogresan email ili lozinka.";
                        $_SESSION['greske']=$greske;
                        header('Location:logovanje.php');
                        
                    }
                }
                catch(PDOException $e){
                    echo $e->getMessage();
            
                }
            }


                
        }
            
        

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}





?>