<?php
session_start();
echo("zdravo");
var_dump($_SESSION['korisnik']);
?>